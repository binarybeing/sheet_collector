# sheet_collector
局域网表单收集

# 局域网表单收集工具
## 使用方法

1.设置电脑固定IP

2.更新client.html上的IP池

3.将client.html发送给需要填表的员工

4.修改collect_task新增收集任务，新增任务文件夹及 对应 表单模块

5.启动服务

